#ifndef BITREVERSE_H
#define BITREVERSE_H
#define init_bitreverse() 
extern ROM BYTE bitreverse[256];
#endif
